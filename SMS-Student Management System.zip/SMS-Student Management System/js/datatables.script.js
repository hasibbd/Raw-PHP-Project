$(document).ready(function() {
    $('#dataTableEx').DataTable();
} );
